"use client";
import { useState, useEffect } from "react";

const KIDS = [
  { quote: "You can do hard things.",                  author: "A message for every child", bg: "#FDE8E8", accent: "#F472B6" },
  { quote: "Be curious. Ask questions. Explore!",      author: "A message for every child", bg: "#E8F0FE", accent: "#3B82F6" },
  { quote: "Mistakes help us learn and grow.",         author: "A message for every child", bg: "#FEF3C7", accent: "#F59E0B" },
  { quote: "Dream big, little one!",                   author: "A message for every child", bg: "#FEF9C3", accent: "#16A34A" },
  { quote: "Kindness makes the world more beautiful.", author: "A message for every child", bg: "#DCFCE7", accent: "#22C55E" },
  { quote: "Every day is a chance to be amazing.",     author: "A message for every child", bg: "#EDE9FE", accent: "#8B5CF6" },
];

// All 6 faces as a lookup by index
function Face({ index, size = 80 }) {
  const cx = 50, cy = 56, r = 34;
  const eyes = (
    <>
      <ellipse cx="39" cy="52" rx="5" ry="6" fill="#fff"/>
      <ellipse cx="61" cy="52" rx="5" ry="6" fill="#fff"/>
      <circle cx="40" cy="53" r="3" fill="#1A0A00"/>
      <circle cx="62" cy="53" r="3" fill="#1A0A00"/>
      <circle cx="41" cy="51" r="1" fill="#fff"/>
      <circle cx="63" cy="51" r="1" fill="#fff"/>
      <ellipse cx="32" cy="63" rx="7" ry="4" fill="#F9A8D4" opacity="0.5"/>
      <ellipse cx="68" cy="63" rx="7" ry="4" fill="#F9A8D4" opacity="0.5"/>
      <path d="M38 68 Q50 78 62 68" stroke="#C97C5A" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
      <path d="M42 68 Q50 74 58 68" fill="#fff"/>
    </>
  );
  const configs = [
    // 0 pink bow girl light
    <svg key={0} viewBox="0 0 100 100" width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="#F5C5A3"/>
      <ellipse cx="50" cy="26" rx="22" ry="14" fill="#5C3D1E"/>
      <circle cx="50" cy="22" r="10" fill="#5C3D1E"/>
      <ellipse cx="36" cy="25" rx="8" ry="5" fill="#F472B6" transform="rotate(-20 36 25)"/>
      <ellipse cx="64" cy="25" rx="8" ry="5" fill="#F472B6" transform="rotate(20 64 25)"/>
      <circle cx="50" cy="24" r="5" fill="#EC4899"/>
      {eyes}
    </svg>,
    // 1 red cap boy medium brown
    <svg key={1} viewBox="0 0 100 100" width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="#C68642"/>
      <ellipse cx="50" cy="28" rx="26" ry="10" fill="#E53E3E"/>
      <rect x="24" y="24" width="52" height="8" rx="2" fill="#C53030"/>
      <rect x="14" y="30" width="20" height="5" rx="2" fill="#E53E3E"/>
      {eyes}
    </svg>,
    // 2 purple bow blonde girl
    <svg key={2} viewBox="0 0 100 100" width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="#FDDCB5"/>
      <ellipse cx="50" cy="26" rx="24" ry="14" fill="#D4A017"/>
      <ellipse cx="30" cy="40" rx="9" ry="18" fill="#D4A017"/>
      <ellipse cx="70" cy="40" rx="9" ry="18" fill="#D4A017"/>
      <ellipse cx="64" cy="27" rx="8" ry="5" fill="#A855F7" transform="rotate(20 64 27)"/>
      <ellipse cx="80" cy="27" rx="8" ry="5" fill="#A855F7" transform="rotate(-20 80 27)"/>
      <circle cx="72" cy="26" r="5" fill="#9333EA"/>
      {eyes}
    </svg>,
    // 3 green cap boy dark brown
    <svg key={3} viewBox="0 0 100 100" width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="#8D5524"/>
      <ellipse cx="50" cy="27" rx="28" ry="10" fill="#16A34A"/>
      <rect x="22" y="23" width="56" height="9" rx="3" fill="#15803D"/>
      <rect x="12" y="30" width="22" height="5" rx="2" fill="#16A34A"/>
      {eyes}
    </svg>,
    // 4 flower girl dark hair
    <svg key={4} viewBox="0 0 100 100" width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="#FDDCB5"/>
      <ellipse cx="50" cy="26" rx="22" ry="14" fill="#1C1008"/>
      <ellipse cx="30" cy="38" rx="8" ry="16" fill="#1C1008"/>
      <ellipse cx="70" cy="38" rx="8" ry="16" fill="#1C1008"/>
      <circle cx="65" cy="19" r="4" fill="#FCD34D"/>
      <circle cx="72" cy="22" r="4" fill="#FCD34D"/>
      <circle cx="72" cy="30" r="4" fill="#FCD34D"/>
      <circle cx="65" cy="33" r="4" fill="#FCD34D"/>
      <circle cx="58" cy="30" r="4" fill="#FCD34D"/>
      <circle cx="58" cy="22" r="4" fill="#FCD34D"/>
      <circle cx="65" cy="26" r="5" fill="#F97316"/>
      {eyes}
    </svg>,
    // 5 gold button boy medium
    <svg key={5} viewBox="0 0 100 100" width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="#C68642"/>
      <ellipse cx="50" cy="26" rx="22" ry="14" fill="#3B1F0A"/>
      <circle cx="67" cy="30" r="6" fill="#F59E0B"/>
      <circle cx="67" cy="30" r="3.5" fill="#FDE68A"/>
      {eyes}
    </svg>,
    // 6 pigtails girl medium skin
    <svg key={6} viewBox="0 0 100 100" width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="#E8B88A"/>
      <ellipse cx="50" cy="26" rx="22" ry="13" fill="#3B1F0A"/>
      <ellipse cx="28" cy="36" rx="7" ry="14" fill="#3B1F0A"/>
      <ellipse cx="72" cy="36" rx="7" ry="14" fill="#3B1F0A"/>
      <circle cx="24" cy="50" r="6" fill="#3B1F0A"/>
      <circle cx="76" cy="50" r="6" fill="#3B1F0A"/>
      <circle cx="24" cy="50" r="4" fill="#E53E3E"/>
      <circle cx="76" cy="50" r="4" fill="#E53E3E"/>
      {eyes}
    </svg>,
    // 7 beanie boy light skin
    <svg key={7} viewBox="0 0 100 100" width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="#F5C5A3"/>
      <ellipse cx="50" cy="27" rx="28" ry="12" fill="#2563EB"/>
      <rect x="22" y="24" width="56" height="10" rx="4" fill="#1D4ED8"/>
      <ellipse cx="50" cy="18" rx="6" ry="6" fill="#F7C948"/>
      {eyes}
    </svg>,
    // 8 afro girl dark skin
    <svg key={8} viewBox="0 0 100 100" width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="#6B3A2A"/>
      <ellipse cx="50" cy="26" rx="26" ry="18" fill="#1C0A00"/>
      <ellipse cx="30" cy="36" rx="12" ry="18" fill="#1C0A00"/>
      <ellipse cx="70" cy="36" rx="12" ry="18" fill="#1C0A00"/>
      <circle cx="65" cy="22" r="5" fill="#22C55E"/>
      <circle cx="65" cy="22" r="3" fill="#16A34A"/>
      {eyes}
    </svg>,
    // 9 curly hair boy medium tan
    <svg key={9} viewBox="0 0 100 100" width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="#D4956A"/>
      <circle cx="35" cy="28" r="10" fill="#5C3D1E"/>
      <circle cx="50" cy="22" r="10" fill="#5C3D1E"/>
      <circle cx="65" cy="28" r="10" fill="#5C3D1E"/>
      <circle cx="28" cy="40" r="9" fill="#5C3D1E"/>
      <circle cx="72" cy="40" r="9" fill="#5C3D1E"/>
      {eyes}
    </svg>,
  ];
  return configs[index % configs.length];
}

const CSS = `
  @keyframes rainbowShift {
    0%   { background-position: 0% 50%; }
    50%  { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }
  @keyframes modalPop {
    from { opacity:0; transform:translate(-50%,-46%) scale(0.88); }
    to   { opacity:1; transform:translate(-50%,-50%) scale(1); }
  }
  @keyframes floatA {
    0%   { transform: translateY(0px)   rotate(0deg)   scale(1); }
    33%  { transform: translateY(-22px) rotate(12deg)  scale(1.05); }
    66%  { transform: translateY(10px)  rotate(-8deg)  scale(0.97); }
    100% { transform: translateY(0px)   rotate(0deg)   scale(1); }
  }
  @keyframes floatB {
    0%   { transform: translateY(0px)  rotate(0deg)  scale(1); }
    40%  { transform: translateY(18px) rotate(-15deg) scale(1.08); }
    80%  { transform: translateY(-12px) rotate(10deg) scale(0.95); }
    100% { transform: translateY(0px)  rotate(0deg)  scale(1); }
  }
  @keyframes floatC {
    0%   { transform: translateY(0px)  rotate(0deg)  scale(1); }
    25%  { transform: translateY(-14px) rotate(20deg) scale(1.1); }
    75%  { transform: translateY(16px) rotate(-12deg) scale(0.92); }
    100% { transform: translateY(0px)  rotate(0deg)  scale(1); }
  }
  @keyframes spinSlow {
    from { transform: rotate(0deg); }
    to   { transform: rotate(360deg); }
  }
  @keyframes pulse {
    0%, 100% { transform: scale(1); opacity: 0.7; }
    50%       { transform: scale(1.18); opacity: 1; }
  }
  @keyframes colorBar {
    0%   { background-position: 0% 50%; }
    50%  { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }
  .q-overlay {
    position: fixed; inset: 0; z-index: 9988;
    background: rgba(220, 220, 225, 0.97);
    backdrop-filter: blur(2px);
    -webkit-backdrop-filter: blur(2px);
  }
  .q-modal {
    position: fixed;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    z-index: 9999;
    width: min(480px, 92vw);
    background: #fff;
    border-radius: 32px;
    padding: 2.5rem 2rem 2rem;
    box-shadow: 0 32px 80px rgba(0,0,0,0.18);
    display: flex; flex-direction: column; align-items: center; text-align: center;
    overflow: hidden;
    animation: modalPop 0.35s cubic-bezier(0.34,1.56,0.64,1) forwards;
  }
  .q-rainbow-bar {
    position: absolute; top: 0; left: 0; right: 0; height: 6px;
    background: linear-gradient(90deg,#E54B4B,#F5A623,#F7C948,#4CAF50,#4BA3E3,#8B5CF6,#E54B4B);
    background-size: 300% 100%;
    animation: colorBar 3s ease infinite;
  }
  .q-float-layer {
    position: fixed; inset: 0; z-index: 9989;
    pointer-events: none; overflow: hidden;
  }
  .q-card {
    border-radius: 20px; padding: 2rem 1.5rem;
    display: flex; flex-direction: column; align-items: center; text-align: center;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    cursor: pointer;
    transition: transform 0.2s, box-shadow 0.2s, border-color 0.2s;
    border: 2px solid transparent; outline: none;
  }
  .q-card:hover { transform: translateY(-5px); box-shadow: 0 14px 32px rgba(0,0,0,0.1); }
`;

// Floating pieces config — faces + shapes scattered around the modal
const FLOATERS = [
  // Faces — various positions around perimeter
  { type: "face", index: 0,  top: "6%",  left: "4%",   size: 68, anim: "floatA", dur: "4.2s", delay: "0s"    },
  { type: "face", index: 2,  top: "5%",  left: "28%",  size: 56, anim: "floatB", dur: "5.1s", delay: "0.4s"  },
  { type: "face", index: 5,  top: "4%",  left: "55%",  size: 62, anim: "floatC", dur: "3.9s", delay: "0.8s"  },
  { type: "face", index: 8,  top: "6%",  left: "80%",  size: 58, anim: "floatA", dur: "4.7s", delay: "1.2s"  },
  { type: "face", index: 1,  top: "38%", left: "1%",   size: 60, anim: "floatB", dur: "4.4s", delay: "0.6s"  },
  { type: "face", index: 6,  top: "38%", left: "88%",  size: 58, anim: "floatC", dur: "5.3s", delay: "1.5s"  },
  { type: "face", index: 9,  top: "72%", left: "3%",   size: 64, anim: "floatA", dur: "3.8s", delay: "0.2s"  },
  { type: "face", index: 3,  top: "74%", left: "30%",  size: 54, anim: "floatB", dur: "4.9s", delay: "1.0s"  },
  { type: "face", index: 7,  top: "72%", left: "57%",  size: 60, anim: "floatC", dur: "4.1s", delay: "0.3s"  },
  { type: "face", index: 4,  top: "70%", left: "83%",  size: 66, anim: "floatA", dur: "5.5s", delay: "0.9s"  },
  // Stars
  { type: "star", top: "14%", left: "16%",  size: 28, color: "#F7C948", anim: "pulse",   dur: "2.1s", delay: "0s"   },
  { type: "star", top: "18%", left: "72%",  size: 22, color: "#4BA3E3", anim: "pulse",   dur: "2.8s", delay: "0.5s" },
  { type: "star", top: "55%", left: "8%",   size: 20, color: "#F472B6", anim: "pulse",   dur: "2.4s", delay: "1.1s" },
  { type: "star", top: "60%", left: "90%",  size: 26, color: "#22C55E", anim: "pulse",   dur: "3.0s", delay: "0.7s" },
  { type: "star", top: "85%", left: "20%",  size: 18, color: "#8B5CF6", anim: "pulse",   dur: "2.2s", delay: "0.3s" },
  { type: "star", top: "88%", left: "75%",  size: 24, color: "#E54B4B", anim: "pulse",   dur: "2.6s", delay: "0.9s" },
  // Spinning circles
  { type: "ring", top: "30%", left: "92%",  size: 40, color: "#F5A62355", anim: "spinSlow", dur: "8s",  delay: "0s"   },
  { type: "ring", top: "50%", left: "3%",   size: 36, color: "#4BA3E355", anim: "spinSlow", dur: "6s",  delay: "1s"   },
  { type: "ring", top: "80%", left: "50%",  size: 44, color: "#F472B655", anim: "spinSlow", dur: "10s", delay: "0.5s" },
  // Dots
  { type: "dot", top: "25%", left: "50%",  size: 14, color: "#F7C948", anim: "floatB", dur: "3.5s", delay: "0.2s" },
  { type: "dot", top: "65%", left: "45%",  size: 12, color: "#4BA3E3", anim: "floatA", dur: "4.0s", delay: "1.4s" },
  { type: "dot", top: "45%", left: "95%",  size: 10, color: "#22C55E", anim: "floatC", dur: "3.2s", delay: "0.6s" },
];

function StarShape({ size, color }) {
  const s = size;
  return (
    <svg width={s} height={s} viewBox="0 0 24 24">
      <polygon
        points="12,2 15.1,8.3 22,9.3 17,14.1 18.2,21 12,17.8 5.8,21 7,14.1 2,9.3 8.9,8.3"
        fill={color}
      />
    </svg>
  );
}

function RingShape({ size, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40">
      <circle cx="20" cy="20" r="16" fill="none" stroke={color} strokeWidth="5" strokeDasharray="12 8"/>
    </svg>
  );
}

function FloatLayer() {
  return (
    <div className="q-float-layer">
      {FLOATERS.map((f, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            top: f.top,
            left: f.left,
            animation: `${f.anim} ${f.dur} ease-in-out ${f.delay} infinite`,
            opacity: f.type === "face" ? 0.9 : 1,
          }}
        >
          {f.type === "face" && (
            <div style={{
              background: "#fff",
              borderRadius: "50%",
              width: f.size,
              height: f.size,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 4px 16px rgba(0,0,0,0.12)",
              padding: 4,
            }}>
              <Face index={f.index} size={f.size - 10} />
            </div>
          )}
          {f.type === "star" && <StarShape size={f.size} color={f.color} />}
          {f.type === "ring" && <RingShape size={f.size} color={f.color} />}
          {f.type === "dot" && (
            <div style={{
              width: f.size, height: f.size,
              borderRadius: "50%",
              background: f.color,
              boxShadow: `0 0 8px ${f.color}`,
            }} />
          )}
        </div>
      ))}
    </div>
  );
}

export default function Quotes() {
  const [active, setActive] = useState(null);

  useEffect(() => {
    if (document.getElementById("q-css")) return;
    const el = document.createElement("style");
    el.id = "q-css";
    el.textContent = CSS;
    document.head.appendChild(el);
  }, []);

  useEffect(() => {
    const fn = (e) => { if (e.key === "Escape") setActive(null); };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, []);

  useEffect(() => {
    document.body.style.overflow = active !== null ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [active]);

  const kid = active !== null ? KIDS[active] : null;

  return (
    <>
      {/* ── SECTION ── */}
      <section style={{ background: "#FFFDF7", padding: "5rem 1rem" }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: "1rem" }}>
            <span style={{
              display: "inline-block", background: "#EBF5FF", color: "#2563EB",
              fontFamily: "DM Sans, sans-serif", fontSize: "0.72rem", fontWeight: 700,
              letterSpacing: "0.14em", textTransform: "uppercase",
              padding: "0.35rem 1rem", borderRadius: "999px",
            }}>
              Words to Grow By
            </span>
          </div>
          <h2 style={{
            textAlign: "center", fontFamily: "Fredoka, sans-serif",
            fontSize: "clamp(1.8rem, 4vw, 2.6rem)", color: "#0F1D3D", marginBottom: "3rem",
          }}>
            Little Hearts,{" "}
            <span style={{ color: "#F5A623" }}>Big Inspiration</span>
          </h2>

          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(230px, 1fr))",
            gap: "1.25rem",
          }}>
            {KIDS.map((k, i) => (
              <div
                key={i}
                className="q-card"
                style={{ background: k.bg }}
                onClick={() => setActive(i)}
                tabIndex={0}
                onKeyDown={(e) => e.key === "Enter" && setActive(i)}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = k.accent)}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = "transparent")}
              >
                <div style={{
                  background: "#fff", borderRadius: "50%",
                  width: 110, height: 110,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  marginBottom: "1.25rem",
                  boxShadow: "0 4px 12px rgba(0,0,0,0.08)", padding: 8,
                }}>
                  <Face index={i} size={88} />
                </div>
                <p style={{
                  fontFamily: "Fredoka, sans-serif", fontSize: "1.05rem",
                  fontWeight: 600, color: "#0F1D3D", lineHeight: 1.4, marginBottom: "0.75rem",
                }}>
                  {k.quote}
                </p>
                <span style={{
                  fontSize: "0.7rem", fontFamily: "DM Sans, sans-serif",
                  color: k.accent, fontWeight: 700,
                  letterSpacing: "0.07em", textTransform: "uppercase",
                }}>
                  Tap to reflect ✦
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── MODAL SYSTEM ── */}
      {active !== null && (
        <>
          {/* Solid light grey overlay */}
          <div className="q-overlay" onClick={() => setActive(null)} />

          {/* Floating faces + shapes layer */}
          <FloatLayer />

          {/* Modal card */}
          {kid && (
            <div className="q-modal">
              <div className="q-rainbow-bar" />

              <button
                onClick={() => setActive(null)}
                style={{
                  position: "absolute", top: 14, right: 14,
                  background: "#f3f4f6", border: "none", borderRadius: "50%",
                  width: 32, height: 32, cursor: "pointer",
                  fontSize: "1rem", color: "#6b7280",
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}
              >✕</button>

              <div style={{
                background: kid.bg, borderRadius: "50%",
                width: 160, height: 160,
                display: "flex", alignItems: "center", justifyContent: "center",
                marginTop: "0.75rem", marginBottom: "1.5rem", padding: 14,
                boxShadow: `0 10px 30px ${kid.accent}44`,
              }}>
                <Face index={active} size={130} />
              </div>

              <p style={{
                fontFamily: "Fredoka, sans-serif",
                fontSize: "clamp(1.25rem, 4vw, 1.65rem)",
                fontWeight: 600, color: "#0F1D3D",
                lineHeight: 1.35, maxWidth: 360, marginBottom: "1rem",
              }}>
                {"\u201C"}{kid.quote}{"\u201D"}
              </p>

              <div style={{
                width: 44, height: 3, borderRadius: 2,
                background: kid.accent, marginBottom: "0.75rem",
              }} />

              <p style={{
                fontFamily: "DM Sans, sans-serif", fontSize: "0.8rem",
                color: "#9ca3af", fontStyle: "italic", marginBottom: "1.75rem",
              }}>
                {kid.author}
              </p>

              <button
                onClick={() => setActive(null)}
                style={{
                  padding: "0.65rem 2.2rem",
                  background: kid.accent, color: "#fff",
                  border: "none", borderRadius: "999px",
                  fontFamily: "Fredoka, sans-serif", fontWeight: 600,
                  fontSize: "1rem", cursor: "pointer",
                  boxShadow: `0 6px 18px ${kid.accent}55`,
                }}
              >
                Close
              </button>
            </div>
          )}
        </>
      )}
    </>
  );
}

const fs = require('fs');
const path = require('path');

const src  = path.join(__dirname, 'Quotes.jsx');
const dest = path.join(__dirname, 'app', 'components', 'Quotes.jsx');

fs.copyFileSync(src, dest);
console.log('Quotes.jsx installed to app/components/');

let page = fs.readFileSync('app/page.jsx', 'utf8');

if (!page.includes("import Quotes")) {
  page = page.replace(
    /import CTA from ['"]\.\/components\/CTA['"];?/,
    "import CTA from './components/CTA';\nimport Quotes from './components/Quotes';"
  );
  console.log('Quotes import added');
} else {
  console.log('Quotes import already present');
}

if (!page.includes('<Quotes')) {
  page = page.replace(/<\/main>/, '<Quotes/></main>');
  console.log('<Quotes/> added to render');
} else {
  console.log('<Quotes/> already in render');
}

fs.writeFileSync('app/page.jsx', page, 'utf8');
console.log('Done. Refresh localhost:3000 and click any card.');
